<?php
require_once "stimulsoft/helper.php";
?>
<!DOCTYPE html>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>frm_sql_smbillsq.mrt - Viewer</title>
	<link rel="stylesheet" type="text/css" href="css/stimulsoft.viewer.office2013.whiteblue.css">
	<script type="text/javascript" src="scripts/stimulsoft.reports.engine.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.reports.export.pack.js"></script>
	<script type="text/javascript" src="scripts/stimulsoft.viewer.pack.js"></script>

	<?php
		StiHelper::init("handler.php", 30);
	?>
	<script type="text/javascript">
		function Start() {
			Stimulsoft.Base.StiLicense.key =
				"6vJhGtLLLz2GNviWmUTrhSqnOItdDwjBylQzQcAOiHkPkIhwQCkyxCcx+aTuRu0+xbRyp8PLcMKXOwrM" +
				"hrjtWYJwLTDjgOVM1u8uRFaIkPKP9UBWkoaJynxEz+9YAfX4iyvtQBygjWULd1kMgGAp2p6IXaINnSsy" +
				"H0AFogx4QryK3+DtNECTST+nh6eCuG5NyQDmAHmIFdx6pLY5ESinVhr4/PHiBbRuFZ+qWU9jSTbRpKSZ" +
				"HSjvKEsmjCNX5orRYljJ4IocxWAwta2X87BwjjZnjC1y6AS8WmjRCNHfLL02cC76IpvgWy483LQKVLEH" +
				"OG5JejXpIVLGM7qw5O+rUyUWePKxQLBMDnUPbiYF5fRDYwvTXzZYaB7t+6eUukdE51lclE/oQlg059Pv" +
				"7rLVYQBz2LH/KRdBB+sbOZf7+jP9uVj9ZW83nap0CPePbi5VXguTfyXd/BgTyyUKmvRMNuNDyMoUre3q" +
				"khlrMk/OPBma6TZgjbuM92By58BnK74zRS1Ln6dODBJh1X0S+W2seqQIEijtRxm02M0m8AgfV0Fqy/fC" +
				"fQh7iFOJoGZHfjWSGy3R9JVY3cChaFoZd6BuphvMQ3VmWzjLePR3Y4IonqPsuMWPlSsIfaEmTerjliAu" +
				"jOze3KxBVLq3mQdg2xKtMRo+GfPjZ+QlhHhVzzeAvJ06Wseyjw7LbH1NPWOgtlQpszzWewAbFn4C7km1" +
				"O6AUPS6ZjZvfSTzAYywJq0qWmsOpJYdP0K1Bq+D9qm94KhP6rB6HRYYkK3DqA/9KvTkvFlrTIsrbA96Z" +
				"5wQPxugzhFBP6OXn5mC2O0E+rn0EO0K8GhyYKarmIR+ZsNW/RkjoSYRE+u2id4/4tyxEKzbWDxrP+iQa" +
				"4045yI3AIH5mNHq09eXk3HiNPwMS6zwNakAaBbJKXYuJw4XPAsrLs/76V3Ee29cr4JExHUxvhR6g9hnl" +
				"mZs9eAaTOR1X7hGMdI/UTB/uw3d2otehXTkTLSKzXi/p7/t5ivhjJwVKZlsA1mzB5fcxxT3ckL0jjs6c" +
				"iEDKr3ZEwmB4Sm5nKQ/Z4C/APUU=";

			Stimulsoft.Base.Localization.StiLocalization.setLocalizationFile("localization/es.xml", true);

			var report = Stimulsoft.Report.StiReport.createNewReport();
			report.loadFile("reports/frm_sql_smbillsq.mrt");

			report.dictionary.variables.getByName("SP_nLang").valueObject = "1";
			report.dictionary.variables.getByName("nLanguage").valueObject = 1;
			report.dictionary.variables.getByName("SP_tCompCode").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tCmpBch").valueObject = "00001";
			report.dictionary.variables.getByName("SP_tDocNo").valueObject = "QT1008822000001";
			report.dictionary.variables.getByName("SP_nAddSeq").valueObject = 10149;
			report.dictionary.variables.getByName("SP_tDocBch").valueObject = "10088";
			report.dictionary.variables.getByName("SP_tGrdStr").valueObject = "";

			var options = new Stimulsoft.Viewer.StiViewerOptions();
			options.appearance.fullScreenMode = true;
			options.toolbar.displayMode = Stimulsoft.Viewer.StiToolbarDisplayMode.Separated;
			
			var viewer = new Stimulsoft.Viewer.StiViewer(options, "StiViewer", false);

			viewer.onPrepareVariables = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.onBeginProcessData = function (args, callback) {
				Stimulsoft.Helper.process(args, callback);
			}

			viewer.report = report;
			viewer.renderHtml("viewerContent");
		}
	</script>
</head>
<body onload="Start()">
	<div id="viewerContent"></div>
</body>
</html>